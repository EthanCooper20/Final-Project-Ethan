﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
public class Pause : MonoBehaviour
{
    public static bool GameisPaused = false;

    private int currentSceneIndex;


    public GameObject pauseMenuUI;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (GameisPaused)
            {
                ResumeGame();
            }
            else
            {
                PauseGame();
            }
        }
    }
    public void ResumeGame()
    {
        pauseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        GameisPaused = false;
    }

    void PauseGame()
    {
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        GameisPaused = true;
    }

    public void SaveGame()
    {
        Save save = CreateSaveGameObject();
        BinaryFormatter BF = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/GameSaved.saved");
        BF.Serialize(file, save);
        file.Close();
    }

    public void LoadGame()
    {
        if(File.Exists(Application.persistentDataPath + "/GameSaved.saved"))
         {
            BinaryFormatter BF = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/GameSaved.saved", FileMode.Open);
            Save save = (Save)BF.Deserialize(file);
            file.Close();
            Lives.LivesAmount = save.numberoflives;
            Points.PointAmount = save.points;
            Timer.timeRemaining = save.timeRemaining;
            Debug.Log("GameLoaded Score: " + save.points);
        }
        else
        {
            Debug.Log("No Game Saved");
        }
    }


    public void QuitGame()
    {
        SceneManager.LoadScene("3Exit");

    }

    public void NewGame()
    {
        SceneManager.LoadScene("2Game");
    }

    public void SaveAsJSON()
    {
        Save save = CreateSaveGameObject();
        string json = JsonUtility.ToJson(save);
        Debug.Log("Saving as JSON: " + json);
    }

    private Save CreateSaveGameObject()
    {
        Save save = new Save();
        save.numberoflives = Lives.LivesAmount;
        save.points = Points.PointAmount;
        save.timeRemaining = Timer.timeRemaining;
        return save;
    }
}
