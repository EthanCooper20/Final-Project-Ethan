﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{

    public static float timeRemaining;
    public Text timeText;

    private void Start()
    {
        timeRemaining = Menu.timerValue;
        // Starts the timer automatically
        Debug.Log(timeRemaining);
        
    }

    void Update()
    {
        timeText.text = timeRemaining.ToString("00.00");
            if (timeRemaining > 0)
            {
                timeRemaining -= Time.deltaTime;
            }
            else
            {
                Debug.Log("Game Over!");
                Time.timeScale = 0;
                timeRemaining = 0;
            }
        
    }

}
