﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public InputField playername;
    public Dropdown livesCountDropdown;

    
    public static float timerValue;
    public static int livesValue;

    public void StartGame(string input)
    {

        Debug.Log("Player Name is:" + playername.text);
        MySettings.playernamestr = playername.text;
        SceneManager.LoadScene("2Game");
    }

    
    public void SetTimerValue(float value)
    {
        timerValue = value;
        Debug.Log(timerValue);
    }


    public void NumberofLives()
    {
        switch (livesCountDropdown.value)
        {
            
            case 1:
                livesValue = 1;
                break;
            case 2:
                livesValue = 2;
                break;
            case 3:
                livesValue = 3;
                break;
            case 4:
                livesValue = 4;
                break;
            case 5:
                livesValue = 5;
                break;
            case 6:
                livesValue = 6;
                break;
            case 7:
                livesValue = 7;
                break;
            case 8:
                livesValue = 8;
                break;
            case 9:
                livesValue = 9;
                break;

            default:
                livesValue = 9;
                break;

        }
    }


}
