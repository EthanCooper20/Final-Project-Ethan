﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Lives : MonoBehaviour
{
    public Text LivesValue;
    public static int LivesAmount;
    

    void Start()
    {

        LivesAmount = Menu.livesValue;
    }

    void Update()
    {
        LivesValue.text = LivesAmount.ToString();
    }

    public void AddLives()
    {
        LivesAmount += 1;
    }

    public void DecreaseLives()
    {
        LivesAmount -= 1;
    }
}
